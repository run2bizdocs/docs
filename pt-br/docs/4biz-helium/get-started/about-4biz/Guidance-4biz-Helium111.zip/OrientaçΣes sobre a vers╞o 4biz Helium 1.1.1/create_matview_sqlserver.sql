-- INI [herbert.cruz]  04.09.2020
-- TODO: Avaliar a permanência dessa view, já na próxima hotfix 
CREATE VIEW dbo.bpm_itemtrabalhofluxo_mv
WITH SCHEMABINDING AS 
SELECT iditemtrabalho, idinstancia, idelemento, idresponsavelatual, datahoracriacao, datahorainicio, situacao 
     , datahorafinalizacao, datahoraexecucao, idstatus, iditemtrabalhobuilder,idinstanciafluxobuilder, idacaofluxo 
     , motivoacao, versaoformbuilder, nomeformbuilder, paginaformbuilder, active 
  FROM dbo.bpm_itemtrabalhofluxo
 WHERE active = 1; 
 -- FIN [herbert.cruz]  04.09.2020