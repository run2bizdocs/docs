DECLARE 
	tbl_exists PLS_INTEGER; 
BEGIN 
	SELECT CASE WHEN EXISTS(SELECT 'X' FROM USER_TABLES WHERE TABLE_NAME = 'AUDITDETAIL' AND OWNER = 'DBO_AUDIT') 
							THEN 1 ELSE 0 
					END INTO tbl_exists FROM DUAL; 
	IF (tbl_exists = 1) THEN 
			EXECUTE IMMEDIATE 
			'DROP TABLE dbo_audit.auditdetail'; 
	END IF; 
END;;

DECLARE 
	tbl_exists PLS_INTEGER; 
BEGIN 
	SELECT CASE WHEN EXISTS(SELECT 'X' FROM USER_TABLES WHERE TABLE_NAME = 'AUDITHEADER'AND OWNER = 'DBO_AUDIT') 
							THEN 1 ELSE 0 
					END INTO tbl_exists FROM DUAL; 
	IF (tbl_exists = 1) THEN 
			EXECUTE IMMEDIATE 
			'DROP TABLE dbo_audit.auditheader'; 
	END IF; 
END;;

DECLARE 
	schm_exists PLS_INTEGER; 
	tbl_header_exists PLS_INTEGER; 
	col_identifier_text_exists PLS_INTEGER; 
	tbl_detail_exists PLS_INTEGER; 
	CONSTRAINT_DOESNOT_EXISTS EXCEPTION; 
	PRAGMA EXCEPTION_INIT(CONSTRAINT_DOESNOT_EXISTS,-23292); 
BEGIN 
	SELECT CASE WHEN EXISTS(SELECT 'X' FROM DBA_USERS WHERE USERNAME = 'DBO_AUDIT') 
							THEN 1 ELSE 0 
					END INTO schm_exists FROM DUAL; 
	IF (schm_exists = 1) THEN 
		
		SELECT CASE WHEN EXISTS(SELECT 'X' FROM DBA_TABLES WHERE TABLE_NAME = 'AUDITHEADER' AND OWNER = 'DBO_AUDIT') 
								THEN 1 ELSE 0 
						END INTO tbl_header_exists FROM DUAL; 
		
		IF (tbl_header_exists = 0) THEN 
			EXECUTE IMMEDIATE 'GRANT REFERENCES ON usuario TO DBO_AUDIT'; 
			
			EXECUTE IMMEDIATE 'GRANT REFERENCES ON ocorrenciasolicitacao TO DBO_AUDIT'; 
			
			EXECUTE IMMEDIATE 
			'CREATE TABLE dbo_audit.auditheader ( 
				id NUMBER NOT NULL, 
				created TIMESTAMP, 
				eventtype VARCHAR2(255), 
				eventmode VARCHAR2(255), 
				ip VARCHAR2(255), 
				entity VARCHAR2(255), 
				keyvalue VARCHAR2(255), 
				identifier VARCHAR2(1700), 
				createdby NUMBER, 
				ticketoccurrence_id NUMBER, 
				CONSTRAINT auditheader_pkey PRIMARY KEY (id), 
				CONSTRAINT auditheader_user_fk FOREIGN KEY (createdby) REFERENCES usuario (idusuario), 
				CONSTRAINT auditdetail_occurrence_fk FOREIGN KEY (ticketoccurrence_id) REFERENCES ocorrenciasolicitacao (idocorrencia) 
			)'; 
			
			EXECUTE IMMEDIATE 
			'CREATE INDEX audit_user_idx ON dbo_audit.auditheader (createdby ASC)'; 
			
			EXECUTE IMMEDIATE 
			'CREATE INDEX audit_created_idx ON dbo_audit.auditheader (created ASC)'; 
			
			EXECUTE IMMEDIATE 
			'CREATE INDEX audit_eventtype_idx ON dbo_audit.auditheader (eventtype ASC)'; 
			
			EXECUTE IMMEDIATE 
			'CREATE INDEX audit_ip_idx ON dbo_audit.auditheader (ip ASC)'; 
			
			EXECUTE IMMEDIATE 
			'CREATE INDEX audit_entity_idx ON dbo_audit.auditheader (entity ASC)'; 
			
			EXECUTE IMMEDIATE 
			'CREATE INDEX audit_keyvalue_idx ON dbo_audit.auditheader (keyvalue ASC)'; 
			
			EXECUTE IMMEDIATE 
			'CREATE INDEX audit_identifier_idx ON dbo_audit.auditheader (identifier ASC)'; 
			
			EXECUTE IMMEDIATE 
			'CREATE INDEX audit_occurrence_idx ON dbo_audit.auditheader (ticketoccurrence_id ASC)'; 
			
			EXECUTE IMMEDIATE 
			'CREATE INDEX ocorr_idcategory_idx ON ocorrenciasolicitacao (idoccurrencecategory ASC)'; 
			
			EXECUTE IMMEDIATE 
			'CREATE INDEX ocorr_idocorrenciapai_idx ON ocorrenciasolicitacao (idocorrenciapai ASC)'; 
			
			EXECUTE IMMEDIATE 
			'CREATE INDEX ocorr_datafim_idx ON ocorrenciasolicitacao (datafim ASC)'; 
			
			EXECUTE IMMEDIATE 
			'INSERT INTO dbo_audit.auditheader (id, created, eventtype, ip, entity, keyvalue, createdby, eventmode, identifier, ticketoccurrence_id) 
				SELECT 
					hibernate_sequence.nextval, 
					to_timestamp(to_char(dataregistro, ''YYYY-MM-DD'') || '' '' || horaregistro, 
					''YYYY-MM-DD HH24:MI''), 
					''TICKET_OCCURRENCE'', 
					''127.0.0.1'', 
					''br.com.centralit.citcorpore.bean.SolicitacaoServicoDTO'', 
					idsolicitacaoservico, 
					COALESCE(registradoporidusuario, (SELECT MAX(idusuario) FROM usuario WHERE login = registradopor)), 
					CASE 
						WHEN COALESCE(registradoporidusuario, (SELECT MAX(idusuario) FROM usuario WHERE login = registradopor)) IS NULL THEN ''AUTOMATICALLY'' 
						ELSE ''MANUALLY'' 
					END, 
					idsolicitacaoservico, 
					idocorrencia 
				FROM ocorrenciasolicitacao 
				WHERE idsolicitacaoservico IS NOT NULL AND idoccurrencecategory <> 1'; 
		END IF; 

		SELECT CASE WHEN EXISTS(SELECT 'X' FROM DBA_TABLES WHERE TABLE_NAME = 'AUDITDETAIL' AND OWNER = 'DBO_AUDIT') 
							THEN 1 ELSE 0 
					END INTO tbl_detail_exists FROM DUAL; 
		
		IF (tbl_detail_exists = 0) THEN 
			EXECUTE IMMEDIATE 
			'CREATE TABLE dbo_audit.auditdetail ( 
				id number NOT NULL, 
				difftype VARCHAR2(255), 
				entity VARCHAR2(255), 
				leftlabel VARCHAR2(255), 
				leftvalue CLOB, 
				property VARCHAR2(255), 
				rightlabel VARCHAR2(255), 
				rightvalue CLOB, 
				header_id NUMBER NOT NULL, 
				mainobject INTEGER, 
				colindex INTEGER, 
				CONSTRAINT auditdetail_pkey PRIMARY KEY (id), 
				CONSTRAINT auditdetail_header_fk FOREIGN KEY (header_id) 
						REFERENCES dbo_audit.auditheader (id) 
			)'; 
		END IF; 
	ELSE 
		RAISE_APPLICATION_ERROR(-20001,'Audit tables were not created because the dbo_audit scheme does not exist!'); 
	END IF; 
END;;